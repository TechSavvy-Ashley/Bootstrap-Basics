1.  **Overview / Introduction:**
    The purpose of this project is to apply Bootstrap utilities, forms, tables, images, and components covered in Module 5 to create a fully functional, responsive web page. In addition to the out-of-box customization from Bootstrap, there are custom .css style sheets for each page to format background color. 

2.  **Contents / File Structure:**
    index.html - Home page
    about.html - About GOAT
    users.html - Register form for users
    " styles.css - CSS external file for corresponding .html     